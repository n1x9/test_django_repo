from django.contrib import admin
from .models import UserBase, Hist

admin.site.register(UserBase)
admin.site.register(Hist)